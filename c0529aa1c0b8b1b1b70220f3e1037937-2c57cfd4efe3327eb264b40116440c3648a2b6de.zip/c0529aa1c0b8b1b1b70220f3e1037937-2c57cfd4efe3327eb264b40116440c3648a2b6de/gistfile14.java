// 1) Faça um programa, utilizando while, que mostre na tela os números de 0 a 100.

package javaapplication5;

public class JavaApplication5 {

    public static void main(String[] args) {
        int a = 0;
        
       
        while (a <= 100) {
            System.out.print(a + "\t"); 
            a++;  
        }
    }
}
