// 1) Escreva um programa para escrever a tabuada do número 8.

package javaapplication1;

public class JavaApplication1 {

    public static void main(String[] args) {
        for (int i = 0; i <= 10; i++) {
            System.out.printf("%d x 8 = %d \n", i, i * 8);
        }
    }
}
